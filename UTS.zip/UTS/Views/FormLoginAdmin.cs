﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS.App.Context;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UTS.Views
{
    public partial class FormLoginAdmin : Form
    {
        private string username;
        private string password;

        public FormLoginAdmin()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Masukkan username dan password terlebih dahulu");
            }
            else
            {
                var loginSuccess = C_Login.login(username, password);

                if (loginSuccess == 1)
                {
                    MessageBox.Show("Login berhasil!");
                    // Tambahkan logika setelah login berhasil, seperti membuka form baru
                }
                else if (loginSuccess == 0)
                {
                    MessageBox.Show("Username atau password salah!");
                }
            }
        }

    }
}

