﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UTS.App.Core;

namespace UTS.App.Context
{
    internal class C_Kontak : DatabaseWrapper
    {
        private static string table = "kontak";
        public static DataTable All()
        {
            string query = "select * from kontak;";
            DataTable dataKontak = queryExecutor(query);
            return dataKontak;
        }
    }
};